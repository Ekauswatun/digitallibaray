<?php 
$koneksi = mysqli_connect("localhost","eka","smkn3tbn","digitallibaray");
 
// Check connection
if (mysqli_connect_errno()){
	echo "Koneksi database gagal : " . mysqli_connect_error();
}
 
?>