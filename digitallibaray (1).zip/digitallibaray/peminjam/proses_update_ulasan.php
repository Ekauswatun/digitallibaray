<?php 
// koneksi database
include '../koneksi.php';
   
// menangkap data yang di kirim dari form
$UlasanID = $_POST['UlasanID'];
$UserID = $_POST['UserID'];
$BukuID = $_POST['BukuID'];
$Ulasan = $_POST['Ulasan'];
$Rating = $_POST['Rating'];
 
// menginput data ke database
//mysqli_query($koneksi,"update ulasanbuku set UserID='$UserID', BukuID='$BukuID', Ulasan='$Ulasan', Rating='$Rating' where UlasanID='$UlasanID'");
mysqli_query($koneksi,"UPDATE `ulasanbuku` SET `UserID` = '$UserID', `BukuID` = '$BukuID', `Ulasan` = '$Ulasan', `Rating` = '$Rating' WHERE UlasanID='$UlasanID'");

// mengalihkan halaman kembali ke kategori.php
header("location:ulasan.php?pesan=update");
 
?>