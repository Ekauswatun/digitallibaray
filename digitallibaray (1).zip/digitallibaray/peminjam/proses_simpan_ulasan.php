<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$UserID = $_POST['UserID'];
$BukuID = $_POST['BukuID'];
$Ulasan = $_POST['Ulasan'];
$Rating = $_POST['Rating'];

// menginput data ke database
//mysqli_query($koneksi,"insert into ulasanbuku values(0,'$UserID' ,'$BukuID', '$Ulasan', '$Rating')");
mysqli_query($koneksi,"INSERT INTO `ulasanbuku` (`UlasanID`, `UserID`, `BukuID`, `Ulasan`, `Rating`) VALUES (NULL,'$UserID' ,'$BukuID', '$Ulasan', '$Rating')");
 
// mengalihkan halaman kembali ke kategori.php
header("location:ulasan.php?pesan=simpan");
 
?>