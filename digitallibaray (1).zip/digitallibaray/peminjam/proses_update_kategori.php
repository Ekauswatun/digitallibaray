<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$KategoriID = $_POST['KategoriID'];
$NamaKateori = $_POST['NamaKateori'];

 
//mysqli_query($koneksi,"update kategoribuku set NamaKategori='$NamaKategori' where KategoriID='$KategoriID'");
mysqli_query($koneksi,"UPDATE `kategoribuku` SET `NamaKateori` = '$NamaKateori' WHERE `kategoribuku`.`KategoriID` = '$KategoriID'");
// mengalihkan halaman kembali ke index.php
header("location:kategori.php?pesan=update");
 
?>