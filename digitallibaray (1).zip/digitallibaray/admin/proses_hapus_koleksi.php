
<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data id yang di kirim dari url
$KategoriBukuID = $_GET['KateoriBukuID'];
 
 
// menghapus data dari database

 
// mengalihkan halaman kembali ke index.php
header("location:koleksi.php?pesan=hapus");

?>