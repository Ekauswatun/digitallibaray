
<?php
// koneksi database
include '../koneksi.php';

// menangkap data id yang dikirim dari url
$KategoriID = $_GET['KategoriID'];

// menghapus data dari database
mysqli_query($koneksi,"delete from kategoribuku where KategoriID='$KategoriID'");

// mengalihkan halaman kembali ke index.php
header("location:kategori.php?pesan=hapus");

?>