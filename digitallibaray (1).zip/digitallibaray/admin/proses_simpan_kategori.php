<?php 
// koneksi database
include '../koneksi.php';
 
// menangkap data yang di kirim dari form
$NamaKateori = $_POST['NamaKateori'];

 
// menginput data ke database
mysqli_query($koneksi,"INSERT INTO `kategoribuku` (`KategoriID`, `NamaKateori`) VALUES (NULL, '$NamaKateori')");
 
// mengalihkan halaman kembali ke index.php
header("location:kategori.php?pesan=simpan");
 
?>